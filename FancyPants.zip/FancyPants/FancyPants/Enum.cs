﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FancyPants
{
    public class Enum
    {
        public enum Type
        {
            Low = 1,
            High = 2,
            A = 3,
            B = 4
        }
    }
}
